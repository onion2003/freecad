<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    // If not logged in, redirect to login page
    header("Location: login.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <style>
        /* General CSS for styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            text-align: center;
            margin-top: 50px;
        }

        h1 {
            color: #333;
        }

        p {
            color: #666;
            margin-bottom: 20px; /* Added margin for better spacing */
        }

        /* Button CSS */
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            text-decoration: none; /* Remove default underline */
            margin: 10px; /* Added margin for spacing */
        }

        .button:hover {
            background-color: #45a049;
        }

        /* Additional styling for links */
        a {
            text-decoration: none;
            color: #fff; /* Set text color for links */
        }

        /* Styling for the paragraph containing the password */
        .password-info {
            background-color: #ddd; /* Light gray background */
            padding: 10px;
            border-radius: 5px;
            max-width: 400px; /* Limiting width for better readability */
            margin: 0 auto 20px; /* Centering the paragraph and adding margin */
        }

         .old-links {
            background-color: transparent; /* Transparent background */
            color: #3498db; /* Button text color */
            border: none;
            padding: 10px 15px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: block;
            position: fixed; /* Positioning at bottom */
            bottom: 20px; /* Distance from bottom */
            left: 50%; /* Center horizontally */
            transform: translateX(-50%); /* Center horizontally */
            width: auto;
            transition: background-color 0.3s, color 0.3s; /* Smooth transition effect */
        }


        .app-update-link {
            background-color: transparent;
            color: #ba162f;
            border: none;
            padding: 10px 15px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: block;
            margin-top: 20px; /* Added margin to separate from form */
        }

        .watsapp-group {
            background-color: transparent;
            color: #0eb35e;
            border: none;
            padding: 10px 15px;
            border-radius: 3px;
            cursor: pointer;
            text-decoration: none;
            display: block;
            margin-top: 20px; /* Added margin to separate from form */
        }

    </style>
</head>
<body>
    <!-- Heading -->
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    
    <!-- Paragraph -->
    <p class="password-info">The password is subscribe_akashdip.</p>
    
    <!-- Button -->
    <a href="../app-web/password-html/pRi3sEnT4tIoN7pAsS8wOrD.html" class="button">next</a> 
    <!-- <a href="https://tiny-hamster-b2a057.netlify.app/pri3sent4tion7pass8word" class="button">next</a> -->
    <a href="userdata.php" class="button">Private</a>
    <br>
    <p>This Private button is only for<br>Super-User Akashdip Mahapatra<br>if you are - login again<p>
     <a href="https://linktr.ee/AkashdipMahapatra" class="old-links">my old links</a>
     <a href="https://drive.google.com/drive/folders/1K3n3W1Tzapd076qzpWjbTroNY8RisXo3" class="app-update-link">app update available - 31/01/2024</a>
    <a href="https://chat.whatsapp.com/GbNI7ADrdhd4FtUq1j5D3K" class="watsapp-group">join the Wats App group</a>
</body>
</html>
