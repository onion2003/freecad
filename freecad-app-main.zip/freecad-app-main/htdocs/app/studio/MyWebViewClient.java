package com.akashdipmahapatra.freecad;

import android.content.Intent;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MyWebViewClient extends WebViewClient {

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String url = request.getUrl().toString();

        // Check if the URL is a social media link
        if (isSocialMediaUrl(url)) {
            // Open the URL in the browser
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            view.getContext().startActivity(intent);
            return true; // Prevent the WebView from loading the URL
        }

        // Load the URL in the WebView
        view.loadUrl(url);
        return true;
    }

    private boolean isSocialMediaUrl(String url) {
        return url.startsWith("https://www.youtube.com/") ||
                url.startsWith("https://youtube.be") ||
                url.startsWith("https://m.youtube.com/") ||
                url.startsWith("https://youtube.com/") ||
                url.startsWith("https://www.youtube.com/channel/") ||
                url.startsWith("https://docs.google.com/forms/") ||
                url.startsWith("https://www.facebook.com/") ||
                url.startsWith("https://www.instagram.com/") ||
                url.startsWith("https://www.linkedin.com/") ||
                url.startsWith("https://linktr.ee/AkashdipMahapatra") ||
                url.startsWith("https://drive.google.com/") ||
                url.startsWith("https://chat.whatsapp.com/");
    }
}
